import React from "react";

function Button() {
    return(
<button>Submit</button>    )

}

export default Button