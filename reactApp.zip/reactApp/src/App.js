import { useEffect, useState } from "react";
import React from "react";
import Button from "./button";


function App() {

  const [data, setData] = useState([])
  useEffect(() => {
    fetch("http://localhost:5000/users")
      .then((data) => data.json())
      .then((data) => setData(data))
  }, [])



  // function getUserData() {
  //   fetch("http://localhost:5000/users")
  //       .then((data) => data.json())
  //       .then((data) => setData(data))
  // }



  return (
    <div>
      {data.map((user) => (
        <div>{user.id}:{user.username}
         
        </div>

      ))}
       <div>
            <Button></Button>

          </div>
    </div>
  )
}
export default App